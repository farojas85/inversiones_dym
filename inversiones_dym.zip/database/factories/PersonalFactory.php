<?php

use Faker\Generator as Faker;

$factory->define(App\personal::class, function (Faker $faker) {
    return [
        //
    ];
});
