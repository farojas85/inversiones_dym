<?php

use Faker\Generator as Faker;

$factory->define(App\Prestamo::class, function (Faker $faker) {
    return [
        //
    ];
});
