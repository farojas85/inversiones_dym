<?php

use Faker\Generator as Faker;

$factory->define(App\Cobranza::class, function (Faker $faker) {
    return [
        //
    ];
});
