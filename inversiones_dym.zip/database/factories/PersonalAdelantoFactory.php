<?php

use Faker\Generator as Faker;

$factory->define(App\PersonalAdelanto::class, function (Faker $faker) {
    return [
        //
    ];
});
