<?php

use Faker\Generator as Faker;

$factory->define(App\personalMonto::class, function (Faker $faker) {
    return [
        //
    ];
});
