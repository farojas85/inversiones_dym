{!! Form::open(['id' =>'form','route' => 'cobranzas.store']) !!}
    @include('cobranza.form')
{!! Form::close() !!}