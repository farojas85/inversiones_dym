{!! Form::open(['id' =>'form','route' => 'roles.store']) !!}
    @include('configuraciones.role.form')
{!! Form::close() !!}