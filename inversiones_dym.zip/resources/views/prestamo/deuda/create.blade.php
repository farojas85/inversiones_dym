{!! Form::open(['id' =>'form','route' => 'prestamos.store']) !!}
    @include('prestamo.deuda.form')
{!! Form::close() !!}