{!! Form::open(['id' =>'form','route' => 'personalmontos.store']) !!}
    @include('prestamo.personalMonto.form')
{!! Form::close() !!}