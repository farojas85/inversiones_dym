{!! Form::open(['id' =>'form','route' => 'personals.store','class'=>'form-horizontal']) !!}
    @include('personal.form')
{!! Form::close() !!}