{!! 
    Form::number('sueldo',$sueldo,
                ['class' => 'form-control','id'=>'sueldo','required'=>''])
!!} 