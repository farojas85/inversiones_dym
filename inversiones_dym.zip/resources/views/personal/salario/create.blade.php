{!! Form::open(['id' =>'form','route' => 'personalsalarios.store','
                class'=>'form-horizontal']) !!}
    @include('personal.salario.form')
{!! Form::close() !!}