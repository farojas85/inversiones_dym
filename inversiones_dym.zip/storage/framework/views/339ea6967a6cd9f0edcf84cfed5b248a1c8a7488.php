<?php echo Form::open(['id' =>'form','route' => 'permissions.store',
                'class'=>'form-horizontal']); ?>

    <?php echo $__env->make('configuraciones.permission.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo Form::close(); ?>