<div class="col-md-12">
        <div class="form-group row">
            <?php echo Form::label('name','Nombre',['class' =>'col-md-3 col-form-label']); ?>

            <div class="col-md-8">
                    <?php echo Form::text('name', null,
                                [   'class' => 'form-control', 'id' => 'name',
                                    'placeholder' => 'Ingrese Nombre', 'required' =>'']); ?>

            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-group row">
            <?php echo Form::label('slug','Slug',['class' =>'col-md-3 col-form-label']); ?>

            <div class="col-md-8">
                <?php echo Form::text('slug', null,
                                [
                                    'class' => 'form-control', 'id' => 'slug',
                                    'placeholder' =>'Ingrese Slug', 'required' => '']); ?>

            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-group row">
            <?php echo Form::label('description','Descripción',['class' =>'col-md-3 col-form-label']); ?>

            <div class="col-md-8">
                <?php echo Form::text('description', null,
                                [
                                    'class' => 'form-control', 'id' => 'description',
                                    'placeholder' =>'Ingrese Descripción'
                                    ]); ?>

            </div>
        </div>
        <div class="form-group row">
            <?php echo Form::label('estado','Estado',['class' =>'col-md-3 col-form-label']); ?>

            <div class="col-md-8">
                    <?php echo Form::select('estado',$estados,null,
                                [   'class' => 'form-control', 'id' => 'estado',
                                    'placeholder' =>'Seleccione',
                                    'required' =>'']); ?>

            </div>
        </div>
    </div>    
    <div class="col-md-12">
        <h4 class="header-title">Permiso Especial</h4>
        <div class="form-group text-center">
            <label><?php echo Form::radio('special','all-access'); ?> Acceso Total</label>
            <label><?php echo Form::radio('special','no-access'); ?> Ningún Acceso</label>
        </div>
    </div>
    <div class="col-md-12 text-right">
        <div class="form-group">
            <button type="button" class="btn btn-success" id="btn-guardar" value="<?php echo e($estadoform); ?>">
                <i class="<?php echo e(($estadoform == 'create') ? 'ti-save' : 'fe-refresh-cw'); ?>"></i>
                <?php echo e(($estadoform =='create') ? 'Guardar' : 'Actualizar'); ?>

            </button>
            <button type="button" class="btn btn-danger waves-effect"  data-dismiss="modal">
                <i class="fa fa-close"></i> Cancelar
            </button>
        </div>
    </div>