<?php $__env->startSection('title-page','Adelantos Personal'); ?>

<?php $__env->startSection('page-content'); ?>

    <section class="section">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/home" class="text-muted">Home</a></li>
            <li class="breadcrumb-item " aria-current="page">Personal</li>
            <li class="breadcrumb-item active" aria-current="page">Adelanto</li>
        </ol>
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Listado Adelantos</h4></h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-1">
                                    <?php if (\Shinobi::can('personaladelantos.create')): ?>
                                    <button class="btn btn-primary" id="btn-agregar"
                                            title="Agregar Adelanto Personal">
                                        <i class="fa fa-plus"></i> Agregar Adelanto Personal
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <hr>
                            <div class="table-responsive" id="tabla-detalle">
                                <table id="model-datatable" class="table table-striped table-bordered border-t0 text-nowrap w-100 table-sm dt-responsive" >
                                    <thead>
                                        <tr>
                                            <th width="5px" >Acciones</th>
                                            <th >ID</th>
                                            <th >Personal</th>
                                            <th >Fecha</th>
                                            <th> Mes</th>
                                            <th >Monto</th>                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $personaladelantos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personalAdelanto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php if (\Shinobi::can('personaladelantos.show')): ?>
                                                <a class="btn btn-info btn-xs modal-show" 
                                                    title="Ver Adelanto Personal"
                                                    href="<?php echo e(route('personaladelantos.show',$personalAdelanto->id)); ?>">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                                <?php endif; ?>
                                                <?php if (\Shinobi::can('personaladelantos.edit')): ?>
                                                <a class="btn btn-warning btn-xs modal-edit" 
                                                    title="Editar Adelanto Personal"
                                                    href="<?php echo e(route('personaladelantos.edit',$personalAdelanto->id)); ?>">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <?php endif; ?>
                                                <?php if (\Shinobi::can('personaladelantos.destroy')): ?>
                                                <a class="btn btn-danger btn-xs modal-destroy" title="Eliminar Adelanto Personal"
                                                    href="<?php echo e(route('personaladelantos.destroy',$personalAdelanto->id)); ?>">
                                                    <i class="fe-trash-2"></i>
                                                </a>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td> <?php echo e($personalAdelanto->personal->nombres." ".$personalAdelanto->personal->apellidos); ?> </td>
                                            <td> <?php echo e($personalAdelanto->fecha); ?> </td>
                                            <td>
                                               <?php
                                                    for($x=1;$x<=count($meses);$x++){
                                                        $idmes = str_pad($x, 2, "0", STR_PAD_LEFT); 
                                                        if($idmes == $personalAdelanto->mes_adelanto){
                                                            echo $meses[$idmes];
                                                        }
                                                    }    
                                               ?>
                                            </td>
                                            <td><?php echo e("S/ ".number_format($personalAdelanto->monto,2)); ?> </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripties'); ?>
<script src="js/principal/personal_adelanto.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>