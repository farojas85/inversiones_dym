<?php $__env->startSection('title-page','Home'); ?>
    
<?php $__env->startSection('page-content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Inversiones DYM</a></li>
                    <li class="breadcrumb-item active">Res&uacute;menes</li>
                </ol>
            </div>
            <h4 class="page-title">Res&uacute;menes</h4>
        </div>
    </div>
</div>
<?php
    //Obtenemos Id del Usuatio
    $user_id = Auth::user()->id;
    $roles = Auth::user()->roles;

    foreach($roles as $role){
        $role_name = $role->name;
    }
?>

<?php switch($role_name):
    case ('cobrador'): ?>
        <?php echo $__env->make('dashboards.cobrador', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php break; ?>
    <?php case ('admin'): ?>
        <?php echo $__env->make('dashboards.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php break; ?>        
<?php endswitch; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>