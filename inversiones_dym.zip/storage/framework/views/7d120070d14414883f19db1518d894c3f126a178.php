<?php echo Form::open(['id' =>'form','route' => 'roles.store']); ?>

    <?php echo $__env->make('configuraciones.role.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo Form::close(); ?>