<?php echo Form::model($permission, 
    [
        'route' => ['permissions.update',$permission->id],'method' => 'PUT',
        'id' => 'form'
    ]); ?>


<?php echo $__env->make('configuraciones.permission.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::close(); ?>