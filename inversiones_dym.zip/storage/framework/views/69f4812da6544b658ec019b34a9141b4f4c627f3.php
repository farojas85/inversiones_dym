<?php echo Form::model($user, 
    [
        'route' => ['users.update',$user->id],'method' => 'PUT',
        'id' => 'form'
    ]); ?>


<?php echo $__env->make('configuraciones.user.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::close(); ?>


