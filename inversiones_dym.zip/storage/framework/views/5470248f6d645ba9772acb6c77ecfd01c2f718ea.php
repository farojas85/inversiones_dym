<table class="table table-hover table-striped table-sm" id="cobranza-table">
    <thead>
        <tr>
            <th width="10px">Acciones</th>
            <th width="5px">#</th>
            <th>fecha</th>
            <th>Nro. Cuotas</th>
            <th>Monto</th>
            <th>Saldo</th>
        </tr>
    </thead>
    <tbody>
<?php $__currentLoopData = $cobranzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cobranza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td></td>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($cobranza->fecha); ?></td>
        <td><?php echo e($cobranza->cantidad_cuotas); ?></td>
        <td><?php echo e("S/ ".number_format($cobranza->monto,2)); ?></td>
        <td><?php echo e("S/ ".number_format($cobranza->saldo,2)); ?></td>        
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>