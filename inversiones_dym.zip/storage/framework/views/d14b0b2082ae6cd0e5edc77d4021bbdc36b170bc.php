<?php echo Form::model($personal, 
    [
        'route' => ['personals.update',$personal->id],'method' => 'PUT',
        'id' => 'form'
    ]); ?>


<?php echo $__env->make('personal.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::close(); ?>