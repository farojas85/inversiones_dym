<?php $__env->startSection('title-page','Permisos/Roles'); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/home" class="text-muted">Home</a></li>
                        <li class="breadcrumb-item " aria-current="page">Configuraciones</li>
                        <li class="breadcrumb-item active" aria-current="page">Permisos / Roles</li>
                    </ol>
                </div>
                <h4 class="page-title">Asignaci&oacute;n Permisos / Roles</h4>                            
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <div class="card-box">
                <h4 class="header-title">Roles</h4>
                <div class="nav flex-column nav-pills nav-pills-tab" id="v-pills-tab" 
                    role="tablist" aria-orientation="vertical">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="nav-link mb-2" id="v-pills-home-tab" data-toggle="pill" 
                        onclick="mostrar_permisos(<?php echo e($role->id); ?>)" role="tab"  href="" aria-controls="v-pills-home"
                        aria-selected="true">
                        <i class="fe-user"></i>
                        <?php echo e($role->name); ?>

                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>   
        </div>
        <div class="col-md-9">
            <div class="card-box">
                <h3 class="header-title">PERMISOS</h3>
                <div class="tab-content pt-0" id="tabla-detalle">
                    <blockquote class="blockquote">
                        <strong class="text-blue">Seleccione Un Rol</strong>
                        <footer class="blockquote-footer text-success">En esta &Aacute;rea Visualizar&aacute;s los permisos que 
                                se van asignar a cada Rol</footer>
                    </blockquote>                   

                </div>
            </div>   
        </div>
    </div>
    <div class="row">
       
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripties'); ?>
<script src="js/configuraciones/permiso_role.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>