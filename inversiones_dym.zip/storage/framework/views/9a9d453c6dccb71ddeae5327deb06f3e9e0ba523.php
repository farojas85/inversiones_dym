<?php echo Form::open(['id' =>'form','route' => 'cobranzas.store']); ?>

    <?php echo $__env->make('cobranza.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo Form::close(); ?>