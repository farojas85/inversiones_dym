<?php echo Form::model($role, ['route' => ['permissionrole.updatePermissions',$role->id],'method' => 'PUT',
                        'id'=>'form']); ?>

    <?php echo form::hidden('hdd_role_id',$role->id); ?>

<div id="table-responsive">
    <table class="table table-stripped nowrap dt-responsive table-bordered" >
        <thead class="thead-dark">
            <th class="text-white" width="5px">N&deg;</th>
            <th class="text-white">Permisos para <?php echo e(mb_strtoupper($role->name)); ?></th>
        </thead>
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <label>
                            <?php echo form::checkbox('permissions[]',$permission->id,null); ?>

                            <?php echo e($permission->name); ?>

                            <small>(<?php echo e($permission->description ? : 'Sin Descripción'); ?>)</small>
                        </label>
                    </td>
                </tr>
            </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<div class="form-group text-center">
    <button class="btn btn-primary" id="btn-guardar" type="button"> 
        <i class="fa fa-refresh"></i> Actualizar
    </button>
</div>
<?php echo Form::Close(); ?>