<div class="left-side-menu">
    <div class="slimscroll-menu">
        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <ul class="metismenu" id="side-menu">

                <li class="menu-title">Navegaci&oacute;n</li>
                <?php if (\Shinobi::can('dashboard.index')): ?>
                <li>
                    <a href="javascript: void(0);">
                        <i class="fe-airplay"></i>
                        <span> Dashboard</span>
                        <span class="menu-arrow"></span>
                    </a>
                    <?php if (\Shinobi::can('home.index')): ?>
                    <ul class="nav-second-level">
                        <li>
                            <a href="/home">Home</a>
                        </li>
                    </ul>
                    <?php endif; ?>
                </li>
                <?php endif; ?>
                <?php if (\Shinobi::can('sistema.index')): ?>                   
                <li>
                    <a href="javascript: void(0);">
                        <i class="fe-cpu"></i>
                        <span> Sistema </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul class="nav-second-level" aria-expanded="false">
                        <?php if (\Shinobi::can('roles.index')): ?>
                        <li>
                            <a href="/roles">Roles</a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Shinobi::can('users.index')): ?>
                        <li>
                            <a href="/users">Usuarios</a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Shinobi::can('permissions.index')): ?>
                        <li>
                            <a href="/permissions">Permisos</a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Shinobi::can('permissionroles.index')): ?>
                        <li>
                            <a href="/permissionroles">Permisos / Roles</a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if (\Shinobi::can('rrhh.index')): ?>
                <li>
                    <a href="javascript: void(0);">
                        <i class="fe-users"></i>
                        <span>Personal</span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul class="nav-second-level">
                        <?php if (\Shinobi::can('personals.index')): ?>
                        <li>
                            <a href="/personals">Personal</a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Shinobi::can('personaladelantos.index')): ?>
                        <li>
                            <a href="/personaladelantos">Adelanto Personal</a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Shinobi::can('personalsalarios.index')): ?>
                        <li>
                            <a href="/personalsalarios">Pagos Personal</a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if (\Shinobi::can('prestamos.home')): ?>
                <li>
                    <a href="javascript: void(0);">
                        <i class="far fa-money-bill-alt"></i>
                        <span> Pr&eacute;stamos </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul class="nav-second-level" aria-expanded="false">
                        <?php if (\Shinobi::can('clientes.index')): ?>
                        <li>
                            <a href="/clientes">Clientes</a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Shinobi::can('personalmontos.index')): ?>
                        <li>
                            <a href="/personalmontos">Asignar Montos</a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Shinobi::can('prestamos.index')): ?>
                        <li>
                            <a href="/prestamos">Asignar Pr&eacute;stamos</a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Shinobi::can('cobranzas.index')): ?>
                        <li>
                            <a href="/cobranzas">Cobranzas</a>
                        </li>
                        <?php endif; ?>
                        
                    </ul>
                </li>
                <?php endif; ?>
        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>
    </div>
    <!-- Sidebar -left -->
</div>