<div class="form-group row">
    <?php echo Form::label('personal_id','Personal',['class' =>'col-form-label col-md-4 text-right']); ?>

    <div class="col-md-8">
        <?php echo Form::select('personal_id',$personals,null,
                            ['class' => 'form-control',
                            'placeholder'=> 'Seleccione Personal',
                            'id'=>'personal_id',
                            'required'=>'']); ?> 
    </div>                                           
</div>
<div class="form-group row">
    <?php echo Form::label('fecha','fecha',['class' =>'col-md-4 col-form-label text-right']); ?>

    <div class="col-md-8">
        <?php echo Form::text('fecha', null,
                        [   'class' => 'form-control', 'id' => 'fecha']); ?>

    </div>
</div>
<div class="form-group row">
    <?php echo Form::label('monto_asignado','Monto',['class' =>'col-md-4 col-form-label text-right']); ?>

    <div class="col-md-8">
        <?php echo Form::number('monto_asignado', null,
                        [   'class' => 'form-control', 'id' => 'monto_asignado',
                            'placeholder' => 'Ingrese Monto a Asignar','required'=>'',
                            'min'=>0]); ?>

    </div>
</div>
<div class="form-group text-center">
    <button type="button" class="btn btn-success" id="btn-guardar" value="<?php echo e($estadoform); ?>" name="btn-guardar">
        <i class="<?php echo e(($estadoform == 'create') ? 'ti-save' : 'fe-refresh-cw '); ?>"></i>
        <?php echo e(($estadoform =='create') ? 'Guardar' : 'Actualizar'); ?>

    </button>
    &nbsp;
    <button type="button" class="btn btn-danger" id="btn-cerrar" data-dismiss="modal">
        <i class="mdi mdi-close "></i> Cerrar
    </button>
</div>

<script>
    $( function() {
        $( "#fecha" ).flatpickr();
    } );
</script>
