<?php $__env->startSection('title-page','Permisos'); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/home" class="text-muted">Home</a></li>
                        <li class="breadcrumb-item " aria-current="page">Configuraciones</li>
                        <li class="breadcrumb-item active" aria-current="page">Permisos</li>
                    </ol>
                </div>
                <h4 class="page-title">PERMISOS</h4>                            
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <h4 class="header-title">LISTADO DE PERMISOS</h4>
                <div class="row">
                    <div class="col-1">
                        <?php if (\Shinobi::can('personalsalarios.create')): ?>
                        <button class="btn btn-primary btn-rounded" id="btn-agregar"
                                title="Agregar Permiso">
                            <i class="fa fa-plus"></i> Agregar Permiso
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
                <hr>
                <div class="table-responsive" id="tabla-detalle">
                    <table id="model-datatable" class="table table-striped table-bordered border-t0 text-nowrap w-100 table-sm" >
                        <thead>
                            <tr>
                                <th  width="10px">Acciones</th>
                                <th  width="10px">ID</th>
                                <th >Nombre</th>
                                <th >Slug</th>
                                <th >Descripción</th>                                            
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if (\Shinobi::can('permissions.show')): ?>
                                    <a class="btn btn-info btn-xs modal-show" 
                                        title="Ver Permiso"
                                        href="<?php echo e(route('permissions.show',$permission->id)); ?>">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if (\Shinobi::can('permissions.edit')): ?>
                                    <a class="btn btn-warning btn-xs modal-edit" 
                                        title="Editar Permiso"
                                        href="<?php echo e(route('permissions.edit',$permission->id)); ?>">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if (\Shinobi::can('permissions.destroy')): ?>
                                    <a class="btn btn-danger btn-xs modal-destroy" 
                                        title="Eliminar Permiso"
                                        href="<?php echo e(route('permissions.destroy',$permission->id)); ?>">
                                        <i class="fe-trash-2"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($permission->name); ?> </td>
                                <td> <?php echo e($permission->slug); ?></td>
                                <td> <?php echo e($permission->description); ?> </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripties'); ?>
<script src="js/configuraciones/permiso.js"></script>
<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>