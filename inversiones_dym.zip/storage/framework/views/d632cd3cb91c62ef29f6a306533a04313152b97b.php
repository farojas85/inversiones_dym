<?php $__env->startSection('title-page','Roles'); ?>
    
<?php $__env->startSection('page-content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="/home">Home</a></li>
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Sistema</a></li>
                        <li class="breadcrumb-item active">Confguraciones</li>
                    </ol>
                </div>
                <h4 class="page-title">Configuraciones</h4>
            </div>
        </div>
    </div>     
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="header-title">Roles</h4>        
                <div class="table-responsive" id="tabla-detalle">
                    <?php if (\Shinobi::can('roles.create')): ?>
                    <button class="btn btn-info btn-rounded" id="btn-agregar"
                            title="Agregar Role">
                        <i class="fa fa-plus"></i> Agregar Role
                    </button>
                    <?php endif; ?>
                    <table id="model-datatable" class="table table-stripped nowrap dt-responsive"  >
                        <thead>
                            <tr>
                                <th width="5px">Acciones</th>
                                <th >ID</th>
                                <th >Rol</th>
                                <th  >Descripción</th>
                                <th >Special</th>
                                <th>Estado</th>                       
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                switch ($rol->special) {
                                    case '': case null: 
                                        $alert = "badge badge-info";
                                        $text ="algún acceso";break;
                                    case 'all-access': 
                                        $alert = "badge badge-blue";
                                        $text ="acceso total";break;
                                    case 'no-access': 
                                        $alert = "badge badge-dark";
                                        $text ="ningún acceso";break;
                                }
                                switch($rol->estado){
                                    case 'activo':
                                        $alert2 = "badge badge-success";break;
                                    case 'inactivo':
                                        $alert2 = "badge badge-secondary";break;
                                    case 'eliminado':
                                        $alert2 = "badge badge-danger";break;
                                }
                            ?>
                            <tr>
                                <td>
                                    <?php if (\Shinobi::can('roles.edit')): ?>
                                    <a class="btn btn-warning btn-xs modal-edit" 
                                        title="Editar Role"
                                        href="<?php echo e(route('roles.edit',$rol->id)); ?>">
                                        <i class="mdi mdi-pencil"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if (\Shinobi::can('roles.destroy')): ?>
                                    <a class="btn btn-danger btn-xs modal-destroy" title="Eliminar Role"
                                        href="<?php echo e(route('roles.destroy',$rol->id)); ?>">
                                        <i class="fe-trash-2"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($rol->name); ?></td>
                                <td><?php echo e($rol->description); ?></td>                                
                                <td>
                                    <div class="<?php echo e($alert); ?>">
                                        <?php echo e($text); ?>

                                    </div>
                                </td>
                                <td>
                                    <span class="<?php echo e($alert2); ?>"><?php echo e($rol->estado); ?></span>
                                </td>                            
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripties'); ?>
<script src="js/configuraciones/role.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>