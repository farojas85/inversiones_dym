<?php echo Form::open(['id' =>'form','route' => 'personalsalarios.store','
                class'=>'form-horizontal']); ?>

    <?php echo $__env->make('personal.salario.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo Form::close(); ?>