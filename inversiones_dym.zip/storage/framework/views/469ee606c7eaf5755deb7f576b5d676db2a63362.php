<?php $__env->startSection('title-page','Clientes'); ?>
   
<?php $__env->startSection('page-content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="/home">Home</a></li>
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Pr&eacute;stamos</a></li>
                        <li class="breadcrumb-item active">Clientes</li>
                    </ol>
                </div>
                <h4 class="page-title">Clientes</h4>
            </div>
        </div>
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Listado Clientes</h4>        
                    <div class="table-responsive" id="tabla-detalle">
                        <?php if (\Shinobi::can('users.create')): ?>
                        <button class="btn btn-info btn-rounded" id="btn-agregar-cliente"
                                title="Agregar Cliente">
                            <i class="fa fa-plus"></i> Agregar Cliente
                        </button>
                        <?php endif; ?>
                        <table id="cliente-datatable" class="table table-striped dt-responsive table-sm" >
                            <thead>
                                <tr>
                                    <th style="width: 100px;">Acciones</th>
                                    <th >ID</th>
                                    <th >Cliente</th>
                                    <th >Personal</th>
                                    <th >Estado</th>                                    
                                </tr>
                            </thead>
                            <tbody>
                            <?php if($todo == 1): ?>                          
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    switch($cliente->estado)
                                    {
                                        case 'activo':$alert = "badge badge-success";break;
                                        case 'inactivo':$alert = "badge badge-dark";break;
                                        case 'suspendido':$alert = "badge badge-secondary";break;
                                        case 'eliminado':$alert = "badge badge-danger";break;
                                    }
                                ?>
                                <tr>
                                    <td>
                                        <?php if (\Shinobi::can('clientes.show')): ?>
                                        <a class="btn btn-blue btn-xs modal-cliente-show" title="Ver Cliente"
                                            href="<?php echo e(route('clientes.show',$cliente->id)); ?>">
                                            <i class="far fa-eye"></i>
                                        </a>
                                        <?php endif; ?>
                                        <?php if (\Shinobi::can('clientes.edit')): ?>
                                        <a class="btn btn-warning btn-xs modal-cliente-edit" 
                                            title="Editar Cliente"
                                            href="<?php echo e(route('clientes.edit',$cliente->id)); ?>">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <?php endif; ?>
                                        <?php if (\Shinobi::can('clientes.destroy')): ?>
                                        <a class="btn btn-danger btn-xs modal-cliente-destroy" title="Eliminar Cliente"
                                            href="<?php echo e(route('clientes.destroy',$cliente->id)); ?>">
                                            <i class="fe-trash-2"></i>
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td> <?php echo e($cliente->nombres." ".$cliente->apellidos); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $cliente->personals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($personal->nombres." ".$personal->apellidos); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td> <span class="<?php echo e($alert); ?>"><?php echo e($cliente->estado); ?></span> </td>
                                </tr>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        switch($cliente->estado)
                                        {
                                            case 'activo':$alert = "badge badge-success";break;
                                            case 'inactivo':$alert = "badge badge-dark";break;
                                            case 'suspendido':$alert = "badge badge-secondary";break;
                                            case 'eliminado':$alert = "badge badge-danger";break;
                                        }
                                    ?>
                                    <tr>
                                        <td>
                                            <?php if (\Shinobi::can('clientes.show')): ?>
                                            <a class="btn btn-blue btn-xs modal-cliente-show" title="Ver Cliente"
                                                href="<?php echo e(route('clientes.show',$cliente->id)); ?>">
                                                <i class="far fa-eye"></i>
                                            </a>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($cliente->cli_nombre." ".$cliente->cli_apel); ?></td>
                                        <td><?php echo e($cliente->per_nombre." ".$cliente->per_apel); ?></td>
                                        <td> <span class="<?php echo e($alert); ?>"><?php echo e($cliente->estado); ?></span> </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripties'); ?>
    <script src="js/prestamo/cliente.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>