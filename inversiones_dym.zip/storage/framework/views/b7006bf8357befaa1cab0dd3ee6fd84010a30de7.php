
<?php echo Form::model($personalmontos,
    [
        'route' => ['personalmontos.updateMonto',$personalmontos->id],'method' => 'PUT',
        'id' => 'form'
    ]); ?>

    <?php
        $nombres = $personal->nombres." ".$personal->apellidos;
    ?>
    <div class="form-group row">
        <?php echo Form::label('nombres','Personal',['class' =>'col-md-3 col-form-label text-right']); ?>

        <div class="col-md-9">
            <?php echo Form::text('nombres', $nombres,
                            [   'class' => 'form-control', 'id' => 'nombres',
                                'placeholder' => 'Ingrese Nombres','disabled'=>'']); ?>

        </div>
    </div>
    <div class="form-group row">
        <?php echo Form::label('fecha','fecha',['class' =>'col-md-3 col-form-label text-right']); ?>

        <div class="col-md-9">
            <?php echo Form::text('fecha', null,
                            [   'class' => 'form-control', 'id' => 'fecha']); ?>

        </div>
    </div>
<?php echo Form::close(); ?>

<script>
    $( function() {
        $( "#fecha" ).flatpickr();
    } );
</script>
<?php $__env->startSection('scripties'); ?>
    <script src="js/prestamo/personal_monto.js"></script>
<?php $__env->stopSection(); ?>