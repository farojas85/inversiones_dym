<?php $__env->startSection('title-page','Configuraciones'); ?>
   
<?php $__env->startSection('page-content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="/home">Home</a></li>
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Sistema</a></li>
                        <li class="breadcrumb-item active">Confguraciones</li>
                    </ol>
                </div>
                <h4 class="page-title">Configuraciones</h4>
            </div>
        </div>
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Roles</h4>        
                    <div class="table-responsive" id="tabla-detalle">
                        <?php if (\Shinobi::can('users.create')): ?>
                        <button class="btn btn-info btn-rounded" id="btn-agregar-usuario"
                                title="Agregar Usuario">
                            <i class="fa fa-plus"></i> Agregar Usuario
                        </button>
                        <?php endif; ?>
                        <table id="user-datatable" class="table table-striped dt-responsive table-sm nowrap" >
                            <thead>
                                <tr>
                                    <th width="5px">Acciones</th>
                                    <th >ID</th>
                                    <th >Usuario</th>
                                    <th >Correo</th>
                                    <th >Rol</th>                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php if (\Shinobi::can('users.edit')): ?>
                                        <a class="btn btn-warning btn-xs modal-user-edit" 
                                            title="Editar Usuario"
                                            href="<?php echo e(route('users.edit',$user->id)); ?>">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <?php endif; ?>
                                        <?php if (\Shinobi::can('users.destroy')): ?>
                                        <a class="btn btn-danger btn-xs modal-destroy" title="Eliminar Usuario"
                                            href="<?php echo e(route('users.destroy',$user->id)); ?>">
                                            <i class="fe-trash-2"></i>
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                    <td> <?php echo e($loop->iteration); ?></td>
                                    <td> <?php echo e($user->name); ?></td>
                                    <td> <?php echo e($user->email); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $user->getRoles(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                switch ($role) {
                                                    case 'admin': $colorbadge = "badge-primary";break;
                                                    case 'master': $colorbadge='badge-info';break;
                                                    case 'analista': $colorbadge='badge-warning';break;
                                                    case 'cobrador': $colorbadge='badge-danger';break;
                                                }
                                            ?>
                                            <span class="badge <?php echo e($colorbadge); ?>"><?php echo e($role); ?></span>&nbsp;
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                                    </td>
                                   
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripties'); ?>
<script src="js/configuraciones/user.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>