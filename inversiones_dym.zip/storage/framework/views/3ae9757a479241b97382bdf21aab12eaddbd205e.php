<?php $__env->startSection('title-page','Deudas Cliente'); ?>
   
<?php $__env->startSection('page-content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="/home">Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Pr&eacute;stamos</a></li>
                    <li class="breadcrumb-item active">Deudas Cliente</li>
                </ol>
            </div>
            <h4 class="page-title">Listado Deudas Clientes</h4>
        </div>
    </div>
    <div class="col-12">
        <div class="card-box" id="view-detalle">
            <h4 class="header-title">Listado de Asignaciones</h4>   
            <div class="row">
                <div class="col-md-2">
                    <?php if (\Shinobi::can('prestamos.create')): ?>
                    <button class="btn btn-info btn-rounded" id="btn-agregar"
                            title="Nuevo Préstamo">
                        <i class="fa fa-plus"></i> Nuevo Préstamo
                    </button>
                    <?php endif; ?>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="table-responsive" id="tabla-detalle">
                    <table id="model-datatable" class="table table-striped dt-responsive table-sm" >
                        <thead>
                            <tr>
                                <th >Acciones</th>
                                <th >ID</th>
                                <th >fecha</th>
                                <th >Cliente</th>
                                <th >Monto Deuda</th>                                 
                                <th>Saldo</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if($role_name == 'admin' || $role_name == 'master' ): ?>
                            <?php $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestamo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                switch($prestamo->estado){
                                    case 'Generado':$clase="badge badge-danger";break;
                                    case 'Pendiente':$clase="badge badge-info";break;
                                    case 'Cancelado':$clase="badge badge-success";break;
                                }
                            ?>
                            <tr>
                                <td>
                                    <?php if (\Shinobi::can('prestamos.show')): ?>
                                    <a class="btn btn-blue btn-xs modal-cliente-show" title="Ver Préstamo"
                                        href="<?php echo e(route('prestamos.show',$prestamo->id)); ?>">
                                        <i class="far fa-eye"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($prestamo->fecha_prestamo); ?></td>
                                <td><?php echo e($prestamo->nombres); ?></td>
                                <td><?php echo e("S/ ".number_format($prestamo->monto,2)); ?></td>
                                <td>
                                    <?php if($prestamo->saldo == '' || $prestamo->saldo == null): ?>
                                        <?php echo e('S/ '.number_format($prestamo->monto,2)); ?>

                                    <?php else: ?>
                                        <?php echo e("S/ ".number_format($prestamo->saldo,2)); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="<?php echo e($clase); ?>"><?php echo e($prestamo->estado); ?></span>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <?php $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestamo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                switch($prestamo->estado){
                                    case 'Generado':$clase="badge badge-danger ";break;
                                    case 'Pendiente':$clase="badge badge-warning";break;
                                    case 'Cancelado':$clase="badge badge-success";break;
                                }
                            ?>
                            <tr>
                                <td>
                                    <?php if (\Shinobi::can('prestamos.show')): ?>
                                    <a class="btn btn-blue btn-xs modal-cliente-show" title="Ver Préstamo"
                                        href="<?php echo e(route('prestamos.show',$prestamo->id)); ?>">
                                        <i class="far fa-eye"></i>
                                    </a>
                                    <?php endif; ?>
                                    <button type="button" class="btn btn-success btn-xs mostrar-cobranza" 
                                        title="Mostrar_Cobranza" onclick="mostrar_cobranza(<?php echo e($prestamo->id); ?>)">
                                        <i class="fas fa-donate"></i>
                                    </button>
                                </td>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($prestamo->fecha_prestamo); ?></td>
                                <td><?php echo e($prestamo->nombres); ?></td>
                                <td><?php echo e("S/ ".number_format($prestamo->monto,2)); ?></td>
                                <td>
                                    <?php if($prestamo->saldo == '' || $prestamo->saldo == null): ?>
                                        <?php echo e('S/ '.number_format($prestamo->monto,2)); ?>

                                    <?php else: ?>
                                        <?php echo e("S/ ".number_format($prestamo->saldo,2)); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="<?php echo e($clase); ?>"><?php echo e($prestamo->estado); ?></span>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripties'); ?>
    <script src="js/prestamo/prestamo.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>