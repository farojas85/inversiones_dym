<?php echo Form::hidden('prestamo_id',$id); ?>

<?php echo Form::hidden('mini_saldo',$minsaldo); ?>


<div class="form-group row">
    <?php echo Form::label('fecha','Fecha',['class' =>'col-form-label col-md-3']); ?>

    <div class="col-md-9">
        <?php echo Form::text('fecha',null,
                            ['class' => 'form-control',
                            'placeholder'=> 'Ingrese fecha',
                            'id'=>'fecha', 'required'=>'']); ?> 
    </div>                                           
</div>
<div class="form-group row">
    <?php echo Form::label('cantidad_cuotas','Nro. Cuotas',['class' =>'col-form-label col-md-3']); ?>

    <div class="col-md-9">
        <?php echo Form::number('cantidad_cuotas',null,
                            ['class' => 'form-control',
                            'placeholder'=> 'Ingrese Número Cuotas',
                            'id'=>'cantidad_cuotas','required'=>'']); ?> 
    </div>                                           
</div>
<div class="form-group row">
    <?php echo Form::label('monto','Monto Pagar',['class' =>'col-form-label col-md-3']); ?>

    <div class="col-md-9">
        <?php echo Form::number('monto',null,
                            ['class' => 'form-control',
                            'placeholder'=> 'Ingrese Monto a Pagar',
                            'id'=>'monto', 'required'=>'']); ?> 
    </div>                                           
</div>
<div class="form-group row">
    <?php echo Form::label('saldo_anterior','Saldo Anterior',['class' =>'col-form-label col-md-3']); ?>

    <div class="col-md-9">
        <?php echo Form::number('saldo_anterior',$minsaldo,
                            ['class' => 'form-control',
                            'placeholder'=> 'Ingrese Monto a Pagar',
                            'id'=>'saldo_anterior', 'required'=>'']); ?> 
    </div>                                           
</div>
<div class="form-group row">
    <?php echo Form::label('saldo_nuevo','Saldo Nuevo',['class' =>'col-form-label col-md-3']); ?>

    <div class="col-md-9">
        <?php echo Form::number('saldo_nuevo',null,
                            ['class' => 'form-control',
                            'placeholder'=> 'Ingrese Monto Pagar para Ver Saldo',
                            'id'=>'saldo_nuevo', 'required'=>'']); ?> 
    </div>                                           
</div>
<div class="form-group text-center">
    <button type="button" class="btn btn-success" id="btn-guardar-cobranza" value="<?php echo e($estadoform); ?>" name="btn-guardar">
        <i class="<?php echo e(($estadoform == 'create') ? 'ti-save' : 'fe-refresh-cw '); ?>"></i>
        <?php echo e(($estadoform =='create') ? 'Guardar' : 'Actualizar'); ?>

    </button>
    &nbsp;
    <button type="button" class="btn btn-danger" id="btn-cerrar" data-dismiss="modal">
        <i class="mdi mdi-close "></i> Cerrar
    </button>
</div>
<script>
    $( function() {
        $( "#fecha" ).flatpickr();
    } );
</script>