<?php $__env->startSection('title-page','AsignarMontos'); ?>
   
<?php $__env->startSection('page-content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="/home">Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Pr&eacute;stamos</a></li>
                    <li class="breadcrumb-item active">Asiganción Montos</li>
                </ol>
            </div>
            <h4 class="page-title">Asiganción Montos al Personal</h4>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="card-box" id="table-detalle">
            <h4 class="header-title">Listado de Asignaciones</h4>
            <div class="row">
                <div class="col-md-2">
                    <?php if (\Shinobi::can('personalmontos.create')): ?>
                    <button class="btn btn-info btn-rounded" id="btn-agregar"
                            title="Nueva Asignación">
                        <i class="fa fa-plus"></i> Nueva Asignaci&oacute;n
                    </button>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="table-responsive" id="tabla-detalle">
                    <table id="model-datatable" class="table table-striped dt-responsive table-sm" >
                        <thead>
                            <tr>
                                <th >Acciones</th>
                                <th >ID</th>
                                <th >Personal</th>
                                <th >Total Montos</th>
                                <th >Total Saldo</th>                                 
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $personalMontos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php if (\Shinobi::can('personalmontos.show')): ?>
                                    <a class="btn btn-blue btn-xs modal-show" 
                                        title="Listado Montos"
                                        href="<?php echo e(route('personalmontos.show',$pm->id)); ?>">
                                        <i class="far fa-eye"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if (\Shinobi::can('personalmontos.edit')): ?>
                                    <a class="btn btn-warning btn-xs modal-edit" 
                                        title="Editar Monto Personal"
                                        href="<?php echo e(route('personalmontos.edit',$pm->id)); ?>">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($pm->nombres); ?></td>
                                <td><?php echo e("S/ ".number_format($pm->total_asignado,2)); ?></td>
                                <td><?php echo e("S/ ".number_format($pm->total_saldo,2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                            <td colspan="5">- Datos No Registrados -</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>                        
                </div>
            </div> 
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripties'); ?>
    <script src="js/prestamo/personal_monto.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>