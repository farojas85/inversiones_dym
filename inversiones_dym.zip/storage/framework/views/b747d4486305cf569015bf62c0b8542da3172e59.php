<div class="row">
    <div class="col-md-6">
        <div class="form-group row">
            <?php echo Form::label('name','Usuario',['class' =>'col-md-4 col-form-label text-right']); ?>

            <div class="col-md-8">
                <?php echo Form::text('name', null,
                            [   'class' => 'form-control', 'id' => 'name',
                                'placeholder' => 'Ingrese Nombre de usuario', 'required' =>'',
                                'data-parsley-pattern'=>"^[0-9a-zA-ZáéíóúüñÑ]+$"]); ?>

            </div>
        </div>
        <div class="form-group row">
            <?php echo Form::label('email','E-mail',['class' =>'col-md-4 col-form-label text-right']); ?>

            <div class="col-md-8">
                <?php echo Form::text('email', null,
                            [   'class' => 'form-control', 'id' => 'email',
                                'placeholder' => 'Ingrese Correo Electrónico', 'required' =>'']); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <h5 class="header-title">Roles</h5>
        <div class="form-group row">
            <ul class="list-unstyled">
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <label>
                        <?php echo form::checkbox('roles[]',$role->id,null); ?>

                        <?php echo e(__($role->name)); ?>

                        <small>(<?php echo e($role->description ? : 'Sin Descripción'); ?>)</small>
                    </label>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<div class="form-group text-center">
    <button type="button" class="btn btn-success" id="btn-user-guardar" value="<?php echo e($estadoform); ?>" name="btn-guardar">
        <i class="<?php echo e(($estadoform == 'create') ? 'fa fa-save' : 'fa fa-refresh'); ?>"></i>
        <?php echo e(($estadoform =='create') ? 'Guardar' : 'Actualizar'); ?>

    </button>
    &nbsp;
    <button type="button" class="btn btn-danger" id="btn-cerrar" data-dismiss="modal">
        <i class="mdi mdi-close "></i> Cerrar
    </button>
</div>