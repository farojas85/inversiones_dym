<?php echo Form::model($role, 
    [
        'route' => ['roles.update',$role->id],'method' => 'PUT',
        'id' => 'form'
    ]); ?>


<?php echo $__env->make('configuraciones.role.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::close(); ?>